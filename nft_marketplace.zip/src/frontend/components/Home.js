import { useState, useEffect } from 'react'
import { ethers } from "ethers"
import { Row, Col, Card, Button } from 'react-bootstrap'
import NftCard from './NFTCard/NftCard'
import Slider from "react-slick";
import Tab from './Tab';
import '../components/IntroPage/Intro.css'
import img from '../images/_Image_.png'
const Home = ({ marketplace, nft }) => {
  const [loading, setLoading] = useState(true)
  const [items, setItems] = useState([])

  const settings = {

    dots: false,
    infinite: true,
    centerMode: true,
    slidesToShow: 2,
    slidesToScroll: 1,
    arrows: true,

  };
  const settings1 = {

    dots: false,
    infinite: true,
    centerMode: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,

  };
  const loadMarketplaceItems = async () => {
    // Load all unsold items
    const itemCount = await marketplace.itemCount()
    let items = []
    for (let i = 1; i <= itemCount; i++) {
      const item = await marketplace.items(i)
      if (!item.sold) {
        // get uri url from nft contract
        let uri = await nft.tokenURI(item.tokenId)
        // use uri to fetch the nft metadata stored on ipfs 

        // https://ipfs.io/ipfs/QmNUTGGCji69Gg4vpnr7DupVuyrhvJPLFejwiEcczYZEq7
        console.log("uri", uri);
        uri = uri.replace("ipfs.infura.io", "infura-ipfs.io");
        console.log("uri1", uri);
        const response = await fetch(uri)

        const metadata = await response.json()
        console.log("response", metadata);
        // get total price of item (item price + fee)
        const totalPrice = await marketplace.getTotalPrice(item.itemId);
        // const totalPrice = 9;
        // Add item to items array
        metadata.image = metadata.image.replace("ipfs.infura.io", "infura-ipfs.io");
        console.log("metadata", metadata.image)
        items.push({
          totalPrice,
          itemId: item.itemId,
          seller: item.seller,
          name: metadata.name,
          description: metadata.description,
          image: metadata.image
        })
      }
    }
    setLoading(false)
    setItems(items)
  }

  const buyMarketItem = async (item) => {
    console.log("item.totalPrice", item.totalPrice);
    await (await marketplace.purchaseItem(item.itemId, { value: item.totalPrice })).wait()
    loadMarketplaceItems()
  }

  useEffect(() => {
    loadMarketplaceItems()
  }, [])
  if (loading) return (
    <main style={{ padding: "1rem 0" }}>
      <h2>Loading...</h2>
    </main>
  )


  return (
    <div className="flex justify-center" >
      {items.length > 0 ? items.length === 1 ?
        <div className="px-5 container">
          <Row xs={1} md={2} lg={4} className="g-4 py-5">
            <div className='Home-silck' >
              <div className='introImg'>
                {/* <img src={img} alt="Logo" className='introImage' /> */}
              </div>

              <div className='introText'>

                <h1><span style={{ color: "#098A45" }}>BUTO</span> MarketPlace</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  .</p>
                <button className='Introbtn'>Learn More</button>


              </div>
              <div style={{ backgroundColor: 'green', }}>
                <Slider {...settings1}  >
                  <div className='Home-silck' >
                    <Card style={{ width: '250px', display: 'flex', alignItems: 'center' }}>
                      <Card.Img variant="top" src={items[0].image} />
                      <Card.Body color="secondary">
                        <Card.Title>{items[0].name}</Card.Title>
                        <Card.Text>
                          {items[0].description}
                        </Card.Text>
                      </Card.Body>
                      <Card.Footer>
                        <div className='d-grid'>
                          <Button onClick={() => buyMarketItem(items[0])} variant="primary" size="lg">
                            {ethers.utils.formatEther(items[0].totalPrice)} ETH
                          </Button>
                        </div>
                      </Card.Footer>
                    </Card>

                  </div>

                </Slider>

              </div>

            </div>

          </Row>
        </div>
        : <div className="px-5 container">
          <Row xs={1} md={2} lg={4} className="g-4 py-5">

            <div className='Home-silck' >
              <div className='introImg'>
                {/* <img src={img} alt="Logo" className='introImage' /> */}
              </div>

              <div className='introText'>

                <h1><span style={{ color: "#098A45" }}>BUTO</span> MarketPlace</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  .</p>
                <button className='Introbtn'>Learn More</button>


              </div>
              <div>
                <Slider {...settings}  >
                  {items.map((item, idx) => {
                    return (
                      <div className='Home-silck' >
                        <Card style={{ width: '250px', display: 'flex', alignItems: 'center' }}>
                          <Card.Img variant="top" src={item.image} />
                          <Card.Body color="secondary">
                            <Card.Title>{item.name}</Card.Title>
                            <Card.Text>
                              {item.description}
                            </Card.Text>
                          </Card.Body>
                          <Card.Footer>
                            <div className='d-grid'>
                              <Button onClick={() => buyMarketItem(item)} variant="primary" size="lg">
                                Buy for {ethers.utils.formatEther(item.totalPrice)} ETH
                              </Button>
                            </div>
                          </Card.Footer>
                        </Card>

                      </div>
                    )

                  }



                  )}
                </Slider>

              </div>

            </div>

          </Row>
        </div> : (
        <main style={{ padding: "1rem 0" }}>
          <h2>No listed assets</h2>
        </main>
      )}
      <Tab />
    </div>
  );
}
export default Home