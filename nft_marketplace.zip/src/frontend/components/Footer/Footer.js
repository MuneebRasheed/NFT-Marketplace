import React from 'react'
import './Footer.css'

export default function Footer() {
    return (
        <div className='FooterMain'>
            CopyRights 2022
        </div>
    )
}
